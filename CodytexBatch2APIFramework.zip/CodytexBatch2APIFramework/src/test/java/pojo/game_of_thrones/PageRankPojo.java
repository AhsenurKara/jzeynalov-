package pojo.game_of_thrones;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PageRankPojo {
    private String title;
    private int rank;
}
